#pragma once
#include "stdafx.h"
void PlaerContrlo();
void Chekmap(Tank* objTank);