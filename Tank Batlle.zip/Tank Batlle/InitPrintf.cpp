
#include "stdafx.h"
#include "InitPrintf.h"
#include "Tanks.h"
#pragma comment(lib,"winmm.lib")

extern int g_map[41][41];
extern int g_AiTankNumFlag;
extern Tank my_Tank;
extern int g_Exit;
extern int g_Double;

void InitGame()
{
	//SetConsoleTitle("Ultracis Tank Batlle in 15PB");
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	SMALL_RECT rc;
	rc.Left = 0;
	rc.Top = 0;
	rc.Right = 108;
	rc.Bottom = 40;
	//��ʱ���ڵĿ���Ϊ40���߶�Ϊ40
	SetConsoleWindowInfo(hOut, TRUE, &rc);
	HANDLE hOut1 = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD Size;
	Size.X = 110;
	Size.Y = 40;
	SetConsoleScreenBufferSize(hOut1, Size);
	DrawMap();
	InitTank();
}

void SetPos(int x, int y)
{
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD position = { x * 2, y };
	SetConsoleCursorPosition(hOut, position);
}

void WriteChar(int x, int y, char* str, int color)
{
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD position = { x * 2, y };
	SetConsoleCursorPosition(hOut, position);
	SetConsoleTextAttribute(hOut, color);
	printf(str);
}
void ShowCursor(bool isShow)
{
	HANDLE hOutStd = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cci;
	cci.dwSize = 1;
	cci.bVisible = isShow;
	SetConsoleCursorInfo(hOutStd, &cci);
}
char GetOper()                                         //��ȡ������Ϣ
{
	if (_kbhit())
	{
		return _getch();
	}
	return 0;
}

void DrawMap()
{
	GetMap();
	ShowMenu();
	for (int i = 0; i < 41; i++)
	{
		for (int j = 0; j < 41; j++)
		{
			if (i == 0 || j == 0 || i == 40 || j == 40)
			{
				WriteChar(i, j, "��", 7 | 8);
			}
		}
	}
	
	if (g_Exit!=0)
	{
		for (int i = 0; i < 41; i++)
		{
			for (int j = 0; j < 41; j++)
			{
				if (g_map[i][j] == 6)
				{

					WriteChar(i, j, "��", 7 | 8);
				}
				else if (g_map[i][j] == 2)
				{
					WriteChar(i, j, "��", 2 | 8);
				}
				else if (g_map[i][j] == 1)
				{
					WriteChar(i, j, "��", 3 | 8);
				}
				else if (g_map[i][j] == 5)
				{
					WriteChar(i, j, "��", 2 | 8);
				}
				SetPos(19, 37);	 printf("���嗀");
				SetPos(19, 38);	 printf("������");
				SetPos(19, 39);	 printf("������");
			}
		}
		ShowCursor(false);
		SetPos(41, 0);
		printf("��������������������������");
		SetPos(46, 3);
		printf("Ultracis ");
		SetPos(43, 5);
		printf("Tank Baltlle in 15PB");
		SetPos(41, 15);
		printf("��������������������������");
		SetPos(46, 29);
		printf("˵����");
		SetPos(44, 32);
		printf("�������������Ʒ���");
		SetPos(44, 35);
		printf("���ּ���1�������ӵ�");
		SetPos(41, 25);
		printf("��������������������������");
	}
	}
	

void GetMap()
{
	int nMap[41][41] = {    { 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 6, 6, 6, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 6, 6, 6, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 6, 6, 6, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 6, 6, 6, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 1, 1, 1, 6, 6, 6, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 1, 1, 1, 6, 6, 6, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 6, 6, 6, 0, 0, 0, 1, 1, 1, 5, 5, 5, 0, 0, 0, 6, 6, 6, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 1, 1, 1, 5, 5, 5, 0, 0, 0, 6, 6, 6, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 1, 1, 1, 5, 5, 5, 0, 0, 0, 6, 6, 6, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 1, 1, 1, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 1, 1, 1, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 1, 1, 1, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 1, 1, 1, 0, 0, 0, 1, 1, 1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 0, 0, 1, 1, 1, 4 },
							{ 4, 1, 1, 1, 0, 0, 0, 1, 1, 1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 0, 0, 1, 1, 1, 4 },
							{ 4, 1, 1, 1, 0, 0, 0, 1, 1, 1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 0, 0, 1, 1, 1, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 6, 6, 6, 6, 6, 6, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 6, 6, 6, 0, 0, 0, 1, 1, 1, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 6, 6, 6, 0, 0, 0, 1, 1, 1, 0, 0, 0, 5, 5, 5, 0, 0, 0, 1, 1, 1, 1, 1, 1, 4 },
							{ 4, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 6, 6, 6, 0, 0, 0, 1, 1, 1, 0, 0, 0, 5, 5, 5, 0, 0, 0, 1, 1, 1, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 5, 5, 5, 0, 0, 0, 1, 1, 1, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 1, 1, 1, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 6, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 1, 1, 1, 0, 0, 0, 6, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 7, 7, 7, 1, 1, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 7, 7, 7, 1, 1, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 7, 7, 7, 1, 1, 0, 0, 0, 0, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4 },
							{ 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 } };
	for (int i = 0; i < 41; i++)
	{
		for (int j = 0; j < 41; j++)
		{
			g_map[i][j] = nMap[j][i];
		}
	}
}

void ShowMenu()                      //��ʾ�˵�
{
	char* Str[] = { "�� ʼ �� Ϸ", "˫ �� �� Ϸ", "�� �� �� ͼ", "�� �� �� Ϸ" };
	for (int i = 20, j = 18, k = 0; j < 25; j++)     //��ӡ�˵�ѡ��
	{
		WriteChar(i, j, Str[k], 7 | 8);
		ShowCursor(false);
		k++; j++;
	}                
		switch (CheckPlaerInput(20, 18, Str))   //���ݼ�����������ѡ���¼�
		{
		case 0:
		{
			ClearScre(20, 18, 8);                         //������Ļ ��������Ϸ���� 
			break;
		}
		case 1:
		{
			ClearScre(20, 18, 8);                            //������Ļ ��������Ϸ���� 
			g_Double = 1;
			break;
		}
		case 2:                                
		{
			ClearScre(20, 18, 8);                            //������Ļ ��������Ϸ���� 
			SetPos(19, 37);	 printf("���嗀");
			SetPos(19, 38);	 printf("������");
			SetPos(19, 39);	 printf("������");
			EditMap();
			break;

		}
		case 3:
		{
			g_Exit=0;                         //�˳���Ϸ  
			break;
		}
	}

}

int CheckPlaerInput(int m, int n, char* Str[])
{
	int ch, m_Inter=0;
	int i = m, j = n, k = (j - 18) / 2;
	WriteChar(i, j, Str[k], 5 | 8);
	ShowCursor(false);
	while (1)
	{
		ch = GetOper();
		if (ch == -32)
		{
			ch = GetOper();
			if (ch == 72 && j == 18)
			{
				continue;
			}
			else if (ch == 72)
			{
				WriteChar(i, j, Str[k], 7 | 8);
				j = j - 2;
				k = (j - 18) / 2;
				WriteChar(i, j, Str[k], 5 | 8);
				ShowCursor(false);
			}
			else if (ch == 80 && j == 24)
			{
				continue;
			}
			else if (ch == 80)
			{
				WriteChar(i, j, Str[k], 7 | 8);
				j = j + 2;
				k = (j - 18) / 2;
				WriteChar(i, j, Str[k], 5 | 8);
				ShowCursor(false);
			}

		}
		else if (ch == 13)         //ȷ��ѡ��˵�
		{
			m_Inter = k;               //�ж�ѡ������ĸ�ѡ��
			break;
		}
	}
	return m_Inter;
}
void ClearScre(int x,int y,int n)
{
	for (int i = x; i < x + n; i++)
	{
		for (int j = y; j < y + n; j++)
		{
			WriteChar(i, j, " ", 7 | 8);
			ShowCursor(false);
		}
	}
}



void EditMap()											//�Զ����ͼ
{
	for (int i = 0; i < 41; i++)
	{ 
		for (int j = 0; j < 41;j++)
		{
			g_map[i][j] = { 0 };
		}
	}
	SetPos(45, 18);
	printf("שǽ��");
	printf("��");
	printf("��");
	SetPos(45, 20);
	printf("��ǽ��");
	printf("��");
	SetPos(45, 22);
	printf("�ݵأ�");
	printf("��");
	HANDLE hIn = GetStdHandle(STD_INPUT_HANDLE);
	SetConsoleMode(hIn, ENABLE_WINDOW_INPUT | ENABLE_MOUSE_INPUT);

	SetPos(46, 29);
	printf("˵����");
	SetPos(44, 32);
	printf("������ѡ������");
	SetPos(44, 35);
	printf("�������沢�˳�");

	int key = 1;//��¼ѡ�����ʼѡ���һ��
	while (1)
	{
		INPUT_RECORD ir = { 0 };
		unsigned long size = 0;
		ReadConsoleInput(
			hIn,  //������
			&ir,  //��ȡ����̨������Ϣ�Ľṹ��
			1,    //�ṹ���м���
			&size //���崫���˶��ٸ��ֽ�
			);
		//�Ǽ����¼�

		if (ir.EventType == KEY_EVENT)
		{
			if (GetAsyncKeyState(VK_UP) & 0x8000)
				{
					if (key > 1)//����ʱѡ����Ϊ��һ��ʱ��UP�Ϸ������Ч
					{
						switch (key)
						{
						case 2:
							SetPos(49, 18);
							printf("��");
							SetPos(49, 20);
							printf("  ");
							--key;
							break;
						case 3:
							SetPos(49, 20);
							printf("��");
							SetPos(49, 22);
							printf("  ");
							--key;
							break;
						}
					}
				}
				else if (GetAsyncKeyState(VK_DOWN)& 0x8000)
				{
					if (key < 3)//����ʱѡ����Ϊ������ʱ��DOWN�·������Ч
					{
						switch (key)
						{
						case 1:
							SetPos(49, 20);
							printf("��");
							SetPos(49, 18);
							printf("  ");
							++key;
							break;
						case 2:
							SetPos(49, 22);
							printf("��");
							SetPos(49, 20);
							printf("  ");
							++key;
							break;
						}
					}
				}
				else if (GetAsyncKeyState(VK_RETURN) & 0x8000)
				{
					return;
				}
		}

		if (ir.EventType == MOUSE_EVENT)
		{
			//�����������µ�ʱ���ٴ�ӡ�ϰ���
			if (ir.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
			{
				int x = ir.Event.MouseEvent.dwMousePosition.X / 2;  //��¼�����������,���������2
				int y = ir.Event.MouseEvent.dwMousePosition.Y;
				if (x > 0 && x < 40 && y < 40 && y > 0)
					if (x > 18 && x < 22 && y > 36){}
					else {
						if (key == 1)
						{
							g_map[x][y] = 1;
							WriteChar(x, y, "��", 5 | 8);
						}
						else if (key == 2)
						{
							g_map[x][y] = 6;
							WriteChar(x, y, "��", 7 | 8);
							printf("��");

						}
						else if (key == 3)
						{
							g_map[x][y] = 5;
							WriteChar(x, y, "��", 7 | 8);
						}
					}
			}
		}

	}
}

void GameOver(bool home)
{
	int timing = 0;
	PlaySoundA(".\\Music\\Die.wav", NULL, SND_ASYNC | SND_NODEFAULT);
	while (1)
	{
		if (timing++ % 30 == 0)         //��Ϸ����ԭ��Ϊ����ֵΪ0
		{
			if (home)               //��Ϸ����ԭ��Ϊ�ϼұ���,����ӡһ��������ʾ���
			{
				SetPos(18, 18);     //����Ļ���Ĵ�ӡ
				printf("�ϼұ���!");
			}
			SetPos(18, 20);         //����Ļ���Ĵ�ӡ
			printf("��Ϸ����!");
			SetPos(45, 18);        //����Ļ��ӡ
			printf("��Ϸ����");
			SetPos(43, 20);
			printf("�밴�س������¿�ʼ!");
			SetPos(43, 22);
			printf("��Esc���˳���Ϸ!");
		
		}
		if (GetAsyncKeyState(0xD) & 0x8000)  //�س���
		{
			system("cls");      
			InitGame();
			break;
		}
		else if (GetAsyncKeyState(0x1B) & 0x8000)  //Esc���˳�	
		{
			g_Exit = 0; break;
		}
		Sleep(20);
	}
}

void Welcome()
{
	int flag = 45;
	PlaySoundA(".\\Music\\TankBGM.wav", NULL, SND_ASYNC | SND_NODEFAULT);
	while (flag >= 25)
	{
		SetPos(10, 10);
		printf("                                                 Ultracis  15PB     							\n ");
		printf("  	                  /////**///                                     /**               \n ");
		printf("  	                      /**         ******         *******         /**  **			\n ");
		printf("  	                      /**        //////**       //**///**        /** ** 			\n ");
		printf("  	                      /**         *******        /**  /**        /****				\n ");
		printf("  	                      /**        **////**        /**  /**        /** /** 			\n ");
		printf("  	                      /**       //********       ***  /**        /**  /***			\n ");
		printf("  	                      //         ////////       ///   //         //  // //			\n ");
 		printf("  	               																	\n ");
 		printf("                      ******                      **        **      **     				\n ");
 		printf("                      /*////**                    /**       /**     /**    				\n ");
 		printf("                      /*   /**       ******      ******     /**     /**      *****		\n ");
 		printf("                      /******       //////**    ///**/      /**     /**     **///**		\n ");
 		printf("                      /*//// **      *******      /**       /**     /**     /*******		\n ");
 		printf("                      /*    /**     **////**      /**       /**     /**     /**//// 		\n ");
 		printf("                      /******* /    /********      //**      ***     ***     //******	\n ");
		printf("                        ///////      ////////       //      ///     ///      //////		\n ");
		flag--;
	}
	SetPos(38, 35);
	system("pause");
	system("cls");
}