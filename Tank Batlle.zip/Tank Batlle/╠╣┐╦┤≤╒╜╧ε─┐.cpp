// ̹�˴�ս��Ŀ.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "InitPrintf.h"
#include "Control.h"
#include "Tanks.h"

int g_map[41][41];
Tank AI_tank[4], my_Tank;
Tank friend_Tank;
Bullet Bullets[10];
int g_Double = 0;
int g_BulletNumFlag = 0;
int g_AiTankNumFlag = 8;
int g_Exit = 1;
int timeCDAi = clock();

int _tmain(int argc, _TCHAR* argv[])
{
	system("mode con cols=110 lines=50");
	Welcome();
	InitGame();
	while (g_Exit)
	{
		PlaerContrlo();
		if (clock() - timeCDAi > 100)
		{
			MoveAiTank(AI_tank);
			timeCDAi = clock();
		}


	}

	return 0;
}

