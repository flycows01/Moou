#include "stdafx.h"
#include "InitPrintf.h"
#include "Tanks.h"
#include "Control.h"
#include "Bullet.h"
#pragma comment(lib,"winmm.lib")

extern Bullet Bullets[10];
extern Tank AI_tank[4], my_Tank, friend_Tank;
extern int g_map[41][41];
extern int g_BulletNumFlag;
extern int g_AiTankNumFlag;
extern int g_Exit;
int buildCD = clock();


void buildBullet(Tank* tanks, int n)
{
	if (tanks->nMy == 1 || tanks->nMy == 2)
	{
		int i = 0;
		PlaySoundA(".\\Music\\Attack.wav", NULL, SND_ASYNC | SND_NODEFAULT);
		if (tanks->nMy == 1)
			i = 0;
		else
			i = 9;
		if (tanks->nAlive == 1)
		{
			{
				Bullets[i].x = tanks->x;
				Bullets[i].y = tanks->y;
				Bullets[i].nMy = 1;
				Bullets[i].nNum = 0;
				Bullets[i].nFlag = 1;
				Bullets[i].nbuild = 1;
				tanks->bulletFlaf = 1;
				switch (tanks->nDdir)
				{
				case UP:
					Bullets[i].nDir = UP;
					Bullets[i].y -= 2;
					break;
				case DOWN:
					Bullets[i].nDir = DOWN;
					Bullets[i].y += 2;
					break;
				case LEFT:
					Bullets[i].nDir = LEFT;
					Bullets[i].x -= 2;
					break;
				case RIGHT:
					Bullets[i].nDir = RIGHT;
					Bullets[i].x += 2;
					break;
				default:break;
				}
			}
		}
	}	
	else
	{
		for (int i = 0; i < n; i++)
		{  
			if (tanks[i].nAlive==1)
			{
				int j = tanks[i].nNnum;
				Bullets[j].x = tanks[i].x;
				Bullets[j].y = tanks[i].y;
				Bullets[j].nMy = 0;
				Bullets[j].nNum = j;
				Bullets[j].nFlag = 1;
				tanks[i].bulletFlaf = 1;
				Bullets[j].nbuild = 1;
				PlaySoundA(".\\Music\\Attack.wav", NULL, SND_ASYNC | SND_NODEFAULT);
				switch (tanks[i].nDdir)
				{
				case UP:
					Bullets[j].nDir = UP;
					Bullets[j].y -= 2;
					g_BulletNumFlag++;
					break;
				case DOWN:
					Bullets[j].nDir = DOWN;
					Bullets[j].y += 2;
					g_BulletNumFlag++;
					break;
				case LEFT:
					Bullets[j].nDir = LEFT;
					Bullets[j].x -= 2;
					g_BulletNumFlag++;
					break;
				case RIGHT:
					Bullets[j].nDir = RIGHT;
					Bullets[j].x += 2;
					g_BulletNumFlag++;
					break;
				default:break;
				}
			}
			}
	}
	return;
}

void moveBullet(Tank* tanks)
{
	if (tanks->bulletFlaf == 1)
	{
		int i = 0;
		if (tanks->nMy == 1)
			i = 0;
		else
			i = 9;
		switch (BulletCheckMap(&Bullets[i]))
		{
			case 0:   Bullets[i].nFlag = 0;      //�����߽� ̹���ӵ���־��0���ӵ�����־��0
				      tanks->bulletFlaf = 0;
					  break;
			case 1:   PlaySoundA(".\\Music\\Boom.wav", NULL, SND_ASYNC | SND_NODEFAULT); 
				      ClearAI(Bullets[i]);       //����AI̹�ˣ����AI̹��
				      tanks->bulletFlaf = 0;
				      Bullets[i].nFlag = 0;
					  g_AiTankNumFlag--;
					  if (g_AiTankNumFlag > 2)
					  {
						  InitAiTank();
					  }
					  break;
			case 2:   ClearObstacle(Bullets[i]);  //����שǽ������ϰ���
					  tanks->bulletFlaf = 0;
					  Bullets[i].nFlag = 0;
					  break;
			case 3:   tanks->bulletFlaf = 0;    //������ǽ���ӵ���ʧ
				      Bullets[i].nFlag = 0;
				      break;
			case 4:   //���ݵ�
					  Bullets[i].nFlag = 2;
					  break;
			case 5:   break;
			case 7:   GameOver(1);
		}
		if (Bullets[i].nFlag == 1)
		{
			WriteChar(Bullets[i].x, Bullets[i].y, "  ", 7 | 8);
		}
		if (Bullets[i].nFlag == 2)
		{
			WriteChar(Bullets[i].x, Bullets[i].y, "��", 2 | 8);
		}
		if (Bullets[i].nFlag != 0)
		{
			switch (Bullets[i].nDir)
			{
				case UP:      Bullets[i].y -= 1;	break;
				case DOWN:    Bullets[i].y += 1;    break;
				case LEFT:    Bullets[i].x -= 1;	break;
				case RIGHT:   Bullets[i].x += 1;    break;
			}
			switch (BulletCheckMap(&Bullets[i]))
			{
				case 0:   Bullets[i].nFlag = 0;
						  tanks->bulletFlaf = 0;
						  break;
				case 1:   PlaySoundA(".\\Music\\Boom.wav", NULL, SND_ASYNC | SND_NODEFAULT);  
					      ClearAI(Bullets[i]);
						  tanks->bulletFlaf = 0;
						  Bullets[i].nFlag = 0;
						  g_AiTankNumFlag--;
						  if (g_AiTankNumFlag > 2)
						  {
							  InitAiTank();
						  }
						  break;
				case 2:   ClearObstacle(Bullets[i]);
						  tanks->bulletFlaf = 0;
						  Bullets[i].nFlag = 0;
					      break;
				case 3:   tanks->bulletFlaf = 0;
					      Bullets[i].nFlag = 0;
					      break;
				case 4:   Bullets[i].nFlag = 2;
					      break;
				case 5:   break;
				case 7:   GameOver(1);
					      g_BulletNumFlag = 0;
						  my_Tank.bulletFlaf = 0;
						  friend_Tank.bulletFlaf = 0;
						  break;
			}
			if (Bullets[i].nFlag !=0)
			{ 
				WriteChar(Bullets[i].x, Bullets[i].y, "��", 7 | 8);
			}
		}
	}
}

void ClearAI(Bullet objBullet)
{
	PlaySoundA(".\\Music\\Boom.wav", NULL, SND_ASYNC | SND_NODEFAULT);
	int nNum = FindAiTank(objBullet);
	WriteChar(objBullet.x, objBullet.y, "  ", 7 | 8);                     //���my̹���ӵ�
	if (Bullets[nNum].nFlag == 1)
	{
		WriteChar(Bullets[nNum].x, Bullets[nNum].y, "  ", 7 | 8);             //���AI̹���ӵ�
	}
	for (int i = 0; i < 3; i++)
	{
		if (AI_tank[i].nNnum == nNum)
		{
			ClearTank(AI_tank[i].x, AI_tank[i].y );
			AI_tank[i].nAlive = 0;
		}
	}
}
void ClearObstacle(Bullet objBullet)
{
	int nNum = 0;
	WriteChar(objBullet.x, objBullet.y, "  ", 4 | 8);
	g_map[objBullet.x][objBullet.y] = �յ�;
	if (objBullet.nDir < 2)
		nNum = 0;
	else
		nNum = 1;
	switch (nNum)
	{
	    case 0:
	           {
				   if (g_map[objBullet.x - 1][objBullet.y] == ��ǽ &&g_map[objBullet.x + 1][objBullet.y] == ��ǽ) { break; }
				   else if (g_map[objBullet.x - 1][objBullet.y] == �ӵ� &&g_map[objBullet.x + 1][objBullet.y] == �ӵ�) { break; }
				   else if (g_map[objBullet.x - 1][objBullet.y] == ��ǽ || g_map[objBullet.x - 1][objBullet.y] == �ӵ�)
				   {
					   WriteChar(objBullet.x + 1, objBullet.y, "  ", 4 | 8);
					   g_map[objBullet.x + 1][objBullet.y] = �յ�;
					   break;
				   }
				   else if (g_map[objBullet.x + 1][objBullet.y] == ��ǽ || g_map[objBullet.x + 1][objBullet.y] == �ӵ�)
				   {
					   WriteChar(objBullet.x - 1, objBullet.y, "  ", 4 | 8);
					   g_map[objBullet.x - 1][objBullet.y] = �յ�;
					   break;
				   }
				   else
				   {
					   WriteChar(objBullet.x - 1, objBullet.y, "  ", 4 | 8);
					   WriteChar(objBullet.x + 1, objBullet.y, "  ", 4 | 8);
					   g_map[objBullet.x - 1][objBullet.y] = �յ�;
					   g_map[objBullet.x + 1][objBullet.y] = �յ�;
					   break;
				   }
		       }
		case 1:
			  {
				  if (g_map[objBullet.x][objBullet.y - 1] == ��ǽ &&g_map[objBullet.x][objBullet.y + 1] == ��ǽ) { break; }
				  if (g_map[objBullet.x][objBullet.y - 1] == �ӵ� &&g_map[objBullet.x][objBullet.y + 1] == �ӵ�) { break; }
				  else if (g_map[objBullet.x][objBullet.y - 1] == ��ǽ || g_map[objBullet.x][objBullet.y - 1] == �ӵ�)
				  {
					  WriteChar(objBullet.x, objBullet.y + 1, "  ", 4 | 8);
					  g_map[objBullet.x][objBullet.y + 1] = �յ�;
					  break;
				  }
				  else if (g_map[objBullet.x][objBullet.y + 1] == ��ǽ || g_map[objBullet.x][objBullet.y + 1] == �ӵ�)
				  {
					  WriteChar(objBullet.x, objBullet.y - 1, "  ", 4 | 8);
					  g_map[objBullet.x][objBullet.y - 1] = �յ�;
					  break;
				  }
				  else
				  {
					  WriteChar(objBullet.x, objBullet.y - 1, "  ", 4 | 8);
					  WriteChar(objBullet.x, objBullet.y + 1, "  ", 4 | 8);
					  g_map[objBullet.x][objBullet.y - 1] = �յ�;
					  g_map[objBullet.x][objBullet.y + 1] = �յ�;
					  break;
				  }
			  }
					
	}
	
}

int BulletCheckMap(Bullet* objBullet)
{ 
	if (objBullet->nMy == 0)        //����AI�ӵ�
	{
		int x1, y1;
		if (Bullets[0].nFlag == 1)
		{
			x1 = Bullets[0].x;
			y1 = Bullets[0].y;
			if (objBullet->x == x1 && objBullet->y == y1)
			{
				Bullets[0].nFlag = 0;      //����Ai̹���ӵ�
				WriteChar(Bullets[0].x, Bullets[0].y, " ", 7 | 8);
				my_Tank.bulletFlaf = 0;
				return 8;
			}
		}

		if (Bullets[9].nFlag == 1)
		{
			x1 = Bullets[9].x;
			y1 = Bullets[9].y;
			if (objBullet->x == x1 && objBullet->y == y1)
			{
				Bullets[9].nFlag = 0;      //����Ai̹���ӵ�
				WriteChar(Bullets[9].x, Bullets[9].y, " ", 7 | 8);
				friend_Tank.bulletFlaf = 0;
				return 8;
			}
		}
	}
		switch (objBullet->nDir)
		{
		case UP:
		{
			if (objBullet->y == 0)
			{
				return 0; break;
			}
		}
		case DOWN:
		{
			if (objBullet->y == 40)
			{
				return 0; break;
			}
		}
		case LEFT:
		{
			if (objBullet->x == 0)
			{
				return 0; break;
			}
		}
		case RIGHT:
		{
			int i = objBullet->x;
			if (i == 40)
			{
				return 0; break;
			}
		}
		}
		if (g_map[objBullet->x][objBullet->y] == AI̹��)
		{
			return 1;
		}
		else if (g_map[objBullet->x][objBullet->y] == שǽ)
		{
			return 2;
		}
		else if (g_map[objBullet->x][objBullet->y] == ��ǽ)     //��i-1 �޸�Ϊ i
		{
			return 3;
		}
		else if (g_map[objBullet->x][objBullet->y] == �ӵ�)
		{
			return 4;
		}
		else if (g_map[objBullet->x][objBullet->y] == my̹��)   //    �ж�my̹��
		{
			return 6;
		}
		else if (g_map[objBullet->x][objBullet->y] == �ϼ�)        //�����ϼ�
		{
			return 7;
		}
		else
		{
			objBullet->nFlag = 1;
			return 5;
		}
}
int FindAiTank(Bullet objNum)
{
	int nNumX = objNum.x;
	int nNumY = objNum.y;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			for (int k = 0; k < 3; k++)
			{
				if (AI_tank[i].x - 1 + j == nNumX && AI_tank[i].y - 1 + k == nNumY)
				{
					AI_tank[i].nAlive = 0;
					return AI_tank[i].nNnum;
				}
			}
		}
	}
}

void moveAiBullet(Tank* tanks, int n)
{
	for (int i = 0; i < n; i++)
	{
		if (tanks[i].bulletFlaf == 1)
		{
			int j = tanks[i].nNnum;                  
			switch (BulletCheckMap(&Bullets[j]))
			{
				case 0:   Bullets[j].nFlag = 0;      //�����߽� ̹���ӵ���־��0���ӵ�����־��0
						  tanks[i].bulletFlaf = 0;
						  g_BulletNumFlag--;
						  break;
				case 1:            //����AI̹�ˣ��ӵ���ʧ
					      tanks[i].bulletFlaf = 0;
						  Bullets[j].nFlag = 0;
						  g_BulletNumFlag--;
						  break;
				case 2:   ClearObstacle(Bullets[j]);  //����שǽ������ϰ���
						  tanks[i].bulletFlaf = 0;
						  Bullets[j].nFlag = 0;
						  g_BulletNumFlag--;
						  break;
				case 3:   tanks[i].bulletFlaf = 0;    //������ǽ���ӵ���ʧ
						  Bullets[j].nFlag = 0;
						  g_BulletNumFlag--;
						  break;
				case 4:  // OverGrassland(Bullets[j]);  //���ݵ�
						  Bullets[j].nFlag = 2;
						  break;
				case 5:   break;
				case 7:   GameOver(1);
				case 8:   tanks[i].bulletFlaf = 0;    //������ǽ���ӵ���ʧ
						  Bullets[j].nFlag = 0;
						  g_BulletNumFlag--;
						  break;
				case 6:   MyTankRelive(Bullets[j]);
						  break;
				
			}
			if (Bullets[j].nFlag == 1)
			{
				WriteChar(Bullets[j].x, Bullets[j].y, "  ", 7 | 8);
			}
			if (Bullets[j].nFlag == 2)
			{
				WriteChar(Bullets[j].x, Bullets[j].y, "��", 2 | 8);
			}
			if (Bullets[j].nFlag != 0)
			{
				switch (Bullets[j].nDir)
				{
					case UP:      Bullets[j].y -= 1;	break;
					case DOWN:    Bullets[j].y += 1;    break;
					case LEFT:    Bullets[j].x -= 1;	break;
					case RIGHT:   Bullets[j].x += 1;    break;
				}
				switch (BulletCheckMap(&Bullets[j]))
				{
					case 0:   Bullets[j].nFlag = 0;
							  tanks[i].bulletFlaf = 0;
							  g_BulletNumFlag--;
							  break;
					case 1:  
						      tanks[i].bulletFlaf = 0;
							  Bullets[j].nFlag = 0;
							  g_BulletNumFlag--;
							  break;
					case 2:   ClearObstacle(Bullets[j]);
							  tanks[i].bulletFlaf = 0;
							  Bullets[j].nFlag = 0;
							  g_BulletNumFlag--;
							  break;
					case 3:   tanks[i].bulletFlaf = 0;
							  Bullets[j].nFlag = 0;
							  g_BulletNumFlag--;
							  break;
					case 4:   Bullets[j].nFlag = 1;
						      break;
					case 5:   break;
					case 6:   MyTankRelive(Bullets[j]);
							  break;	          //��AI̹�˵Ľ���������������
					case 7:   GameOver(1);
					case 8:  
							  tanks[i].bulletFlaf = 0;    //������ǽ���ӵ���ʧ
							  Bullets[j].nFlag = 0;
							  g_BulletNumFlag--;
							  break;
				}
				if (Bullets[j].nFlag != 0)
				{
					WriteChar(Bullets[j].x, Bullets[j].y, "��", 7 | 8);
				}
			}
		}
	}
}

void MyTankRelive(Bullet objBullet)
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (my_Tank.x - 1 + i == objBullet.x && my_Tank.y - 1 + j == objBullet.y)
			{
				my_Tank.nAlive = 0;
			}
		}
	}
	if (my_Tank.nAlive == 0)
	{
		ClearTank(my_Tank.x, my_Tank.y);
		if (my_Tank.nRevive > 0 && Bullets[0].nFlag == 0 )
		{
			PlaySoundA(".\\Music\\Relive.wav", NULL, SND_ASYNC | SND_NODEFAULT);
			InitMyTank();                             //my̹�˸��������һ
		}
		else
		{
			if (friend_Tank.nRevive == 0)
			GameOver(1);    //��AI̹�˵Ľ���������������
		}
	}
	else
	{
		ClearTank(friend_Tank.x, friend_Tank.y);
		if (friend_Tank.nRevive > 0 && Bullets[9].nFlag == 0)
		{
			PlaySoundA(".\\Music\\Relive.wav", NULL, SND_ASYNC | SND_NODEFAULT);
			InitMyTank();                             //my̹�˸��������һ
		}
		else
		{
			if (my_Tank.nRevive==0)
			GameOver(1);    //��AI̹�˵Ľ���������������
		}
	}
}