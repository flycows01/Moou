#include "stdafx.h"
#include "Tanks.h"
#include "Bullet.h"
#include "InitPrintf.h"

extern Tank AI_tank[4], my_Tank, friend_Tank;
extern int g_map[41][41];
extern int g_BulletNumFlag;
extern int g_AiTankNumFlag;
extern int g_Double;

int timeCD = clock();
int ftimeCD = clock();
int bulletCD = clock();
int fbulletCD = clock();
int AibulletCD = clock();


void PlaerContrlo()
{
	if (g_Double == 1)
	{
		if (GetAsyncKeyState('M') & 0x8000)
		{
			if (friend_Tank.bulletFlaf == 0)
			{
				buildBullet(&friend_Tank, 1);
			}
		}

		if (friend_Tank.bulletFlaf == 1)
		{
			if (clock() - fbulletCD > 50)             
			{
				moveBullet(&friend_Tank);
				fbulletCD = clock();
			}
		}
		if (clock() - ftimeCD > 100)                    
		{
			if (GetAsyncKeyState('W') & 0x8000)
				MoveMyTank(&friend_Tank,UP);
			else if (GetAsyncKeyState('S') & 0x8000)
				MoveMyTank(&friend_Tank,DOWN);
			else if (GetAsyncKeyState('A') & 0x8000)
				MoveMyTank(&friend_Tank,LEFT);
			else if (GetAsyncKeyState('D') & 0x8000)
				MoveMyTank(&friend_Tank,RIGHT);
			ftimeCD = clock();
		}
	}
	if (GetAsyncKeyState('1') & 0x8000)
	{
		if (my_Tank.bulletFlaf == 0)
		{ 
			buildBullet(&my_Tank,1);
		}
	}

	if (my_Tank.bulletFlaf==1)
	{ 
		if (clock() - bulletCD > 50)
		{ 
			moveBullet(&my_Tank);
			bulletCD = clock();
		}
	}
	if (clock() - timeCD > 100)
	{
		if (GetAsyncKeyState(VK_UP) & 0x8000)
			MoveMyTank(&my_Tank, UP);
		else if (GetAsyncKeyState(VK_DOWN) & 0x8000)
			MoveMyTank(&my_Tank, DOWN);
		else if (GetAsyncKeyState(VK_LEFT) & 0x8000)
			MoveMyTank(&my_Tank, LEFT);
		else if (GetAsyncKeyState(VK_RIGHT) & 0x8000)
			MoveMyTank(&my_Tank, RIGHT);
		timeCD = clock();
	}
	if (g_BulletNumFlag == 0)
	{
 		buildBullet(AI_tank, 3);
	}
	if (g_AiTankNumFlag!=0)
	{
		if (clock() - AibulletCD > 50)
		{
			moveAiBullet(AI_tank, 3);
			AibulletCD = clock();
		}
	}
	SetPos(44, 7);
	printf("�з�ʣ��̹�ˣ�%d", g_AiTankNumFlag);
	SetPos(44, 9);
	printf("�ҷ�ʣ��̹�ˣ�%d", my_Tank.nRevive);
}


void Chekmap(Tank* objTank)
{

		if (objTank->x < 2)
		{
			objTank->x = 2;
			objTank->nStop = 1;
		}
		else if (objTank->x > 38)
		{
			objTank->x = 38;
			objTank->nStop = 1;
		}
		if (objTank->y < 2)
		{
			objTank->y = 2;
			objTank->nStop = 1;
		}
		else if (objTank->y > 38)
		{
			objTank->y = 38;
			objTank->nStop = 1;
		}
		switch (objTank->nDdir)
		{
		case UP:
		{
			if (g_map[objTank->x][objTank->y - 1] == שǽ || g_map[objTank->x][objTank->y - 1] == ��ǽ || g_map[objTank->x][objTank->y - 1] == AI̹�� || g_map[objTank->x][objTank->y - 1] == my̹��||
				g_map[objTank->x - 1][objTank->y - 1] == שǽ || g_map[objTank->x - 1][objTank->y - 1] == ��ǽ || g_map[objTank->x - 1][objTank->y - 1] == AI̹�� || g_map[objTank->x - 1][objTank->y - 1] == my̹�� ||
				g_map[objTank->x + 1][objTank->y - 1] == שǽ || g_map[objTank->x + 1][objTank->y - 1] == ��ǽ || g_map[objTank->x + 1][objTank->y - 1] == AI̹�� || g_map[objTank->x + 1][objTank->y - 1] == my̹��
				)
			{
				objTank->y = objTank->y + 1;
				objTank->nStop = 1; break;
			}
			else if (g_map[objTank->x][objTank->y-1] == �ݵ� || g_map[objTank->x][objTank->y-1] == �ӵ�||
				     g_map[objTank->x - 1][objTank->y] == �ݵ� || g_map[objTank->x - 1][objTank->y-1] == �ӵ�||
					 g_map[objTank->x + 1][objTank->y] == �ݵ� || g_map[objTank->x + 1][objTank->y-1] == �ӵ�)
			{
				objTank->invisibleFlag = 1; break;
			}
			else if (g_map[objTank->x - 1][objTank->y + 1] == �յ�&&g_map[objTank->x + 1][objTank->y + 1] == �յ�)
			{
				objTank->invisibleFlag = 0;
				objTank->nStop = 0; break;
			}
		}
		case DOWN:
		{
			if (g_map[objTank->x][objTank->y + 1] == שǽ || g_map[objTank->x][objTank->y + 1] == ��ǽ || g_map[objTank->x][objTank->y + 1] == AI̹�� || g_map[objTank->x][objTank->y + 1] == my̹�� ||
				g_map[objTank->x - 1][objTank->y + 1] == שǽ || g_map[objTank->x - 1][objTank->y + 1] == ��ǽ || g_map[objTank->x - 1][objTank->y + 1] == AI̹�� || g_map[objTank->x - 1][objTank->y + 1] == my̹�� ||
				g_map[objTank->x + 1][objTank->y + 1] == שǽ || g_map[objTank->x + 1][objTank->y + 1] == ��ǽ || g_map[objTank->x + 1][objTank->y + 1] == AI̹�� || g_map[objTank->x + 1][objTank->y + 1] == my̹��)
			{
				objTank->y = objTank->y - 1;
				objTank->nStop = 1; break;
			}
			else if (g_map[objTank->x][objTank->y+1] == �ݵ� || g_map[objTank->x][objTank->y+1] == �ӵ�||
				     g_map[objTank->x-1][objTank->y + 1] == �ݵ� || g_map[objTank->x-1][objTank->y + 1] == �ӵ�||
					 g_map[objTank->x+1][objTank->y + 1] == �ݵ� || g_map[objTank->x+1][objTank->y + 1] == �ӵ�)
			{
				objTank->invisibleFlag = 1; break;
			}
			else if (g_map[objTank->x - 1][objTank->y - 1] == �յ�&&g_map[objTank->x + 1][objTank->y - 1] == �յ�)
			{
				objTank->invisibleFlag = 0;
				objTank->nStop = 0; break; 
			}
		}
		case LEFT:
		{
			if (g_map[objTank->x - 1][objTank->y] == שǽ || g_map[objTank->x - 1][objTank->y] == ��ǽ || g_map[objTank->x - 1][objTank->y] == AI̹�� || g_map[objTank->x - 1][objTank->y] == my̹�� ||
				g_map[objTank->x - 1][objTank->y - 1] == שǽ || g_map[objTank->x - 1][objTank->y - 1] == ��ǽ || g_map[objTank->x - 1][objTank->y - 1] == AI̹�� || g_map[objTank->x - 1][objTank->y - 1] == my̹�� ||
				g_map[objTank->x - 1][objTank->y + 1] == שǽ || g_map[objTank->x - 1][objTank->y + 1] == ��ǽ || g_map[objTank->x - 1][objTank->y + 1] == AI̹�� || g_map[objTank->x - 1][objTank->y + 1] == my̹��)
			{
				objTank->x = objTank->x + 1; 
				objTank->nStop = 1; break;
			}
			else if (g_map[objTank->x-1][objTank->y] == �ݵ� || g_map[objTank->x-1][objTank->y] == �ӵ�||
				     g_map[objTank->x - 1][objTank->y-1] == �ݵ� || g_map[objTank->x - 1][objTank->y-1] == �ӵ�||
					 g_map[objTank->x - 1][objTank->y+1] == �ݵ� || g_map[objTank->x - 1][objTank->y+1] == �ӵ�)
			{
				objTank->invisibleFlag = 1; break;
			}
			else if (g_map[objTank->x + 1][objTank->y - 1] == �յ�&&g_map[objTank->x + 1][objTank->y + 1] == �յ�)
			{
				objTank->invisibleFlag = 0; 
				objTank->nStop = 0; break;
			}
		}
		case RIGHT:
		{
			if (g_map[objTank->x + 1][objTank->y] == שǽ || g_map[objTank->x + 1][objTank->y] == ��ǽ || g_map[objTank->x + 1][objTank->y] == AI̹�� || g_map[objTank->x + 1][objTank->y] == my̹�� ||
				g_map[objTank->x + 1][objTank->y - 1] == שǽ || g_map[objTank->x + 1][objTank->y - 1] == ��ǽ || g_map[objTank->x + 1][objTank->y - 1] == AI̹�� || g_map[objTank->x + 1][objTank->y - 1] == my̹�� ||
				g_map[objTank->x + 1][objTank->y + 1] == שǽ || g_map[objTank->x + 1][objTank->y + 1] == ��ǽ || g_map[objTank->x + 1][objTank->y + 1] == AI̹�� || g_map[objTank->x + 1][objTank->y + 1] == my̹��)
			{
				objTank->x = objTank->x - 1;
				objTank->nStop = 1; break;
			}
			else if (g_map[objTank->x + 1][objTank->y] == �ݵ� || g_map[objTank->x + 1][objTank->y] == �ӵ� ||
				     g_map[objTank->x + 1][objTank->y-1] == �ݵ� || g_map[objTank->x + 1][objTank->y-1] == �ӵ�||
					 g_map[objTank->x + 1][objTank->y+1] == �ݵ� || g_map[objTank->x + 1][objTank->y+1] == �ӵ�)
			{
				objTank->invisibleFlag = 1; break;
			}
			else if (g_map[objTank->x - 1][objTank->y - 1] == �յ�&&g_map[objTank->x - 1][objTank->y + 1] == �յ�)
			{
				objTank->invisibleFlag = 0;
				objTank->nStop = 0; break;
			}
		}
		default: break;
		}
}



