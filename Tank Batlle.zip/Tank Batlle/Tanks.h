#pragma once

void InitTank();
void DrawTank(int x, int y, int color, int dir);
void MoveMyTank(Tank* objTank, int n);
void MoveAiTank(Tank Tanks[]);
void ClearTank(int x, int y);
void InitMyTank();
void InitAiTank();