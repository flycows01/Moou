
#include "stdafx.h"
#include "InitPrintf.h"
#include "Tanks.h"
#include "Control.h"
#include "Bullet.h"

extern Tank AI_tank[4], my_Tank, friend_Tank;
extern int g_map[41][41];
extern int g_BulletNumFlag;
extern int g_AiTankNumFlag;
extern Bullet Bullets[10];
extern int g_Double;

void InitTank()
{
	my_Tank.x = 15;
	my_Tank.y = 38; 
	my_Tank.nColor = 7 | 8;
	my_Tank.nDdir = 0;
	my_Tank.nRevive = 3;
	my_Tank.nMy = 1;
	my_Tank.nAlive = 1;
	my_Tank.bulletFlaf = 0;
	DrawTank(my_Tank.x, my_Tank.y, my_Tank.nColor, my_Tank.nDdir);
	if (g_Double == 1)
	{
		friend_Tank.x = 25;
		friend_Tank.y = 38;
		friend_Tank.nColor = 9 | 8;
		friend_Tank.nDdir = 0;
		friend_Tank.nRevive = 3;
		friend_Tank.nMy = 2;
		friend_Tank.nAlive = 1;
		friend_Tank.bulletFlaf = 0;
		DrawTank(friend_Tank.x, friend_Tank.y, friend_Tank.nColor, friend_Tank.nDdir);
	}
	int pos[3]= { 2, 20, 38 };
	for (int i = 0; i < 3; i++)
	{
		AI_tank[i].x = pos[i];
		AI_tank[i].y = 2;
		AI_tank[i].nColor = 1 + rand() % 6;
		AI_tank[i].nDdir = 1;
		AI_tank[i].nNnum = i+1;
		AI_tank[i].nAlive = 1;
		AI_tank[i].nStop = 0;
		AI_tank[i].bulletFlaf = 0;
		DrawTank(AI_tank[i].x, AI_tank[i].y, AI_tank[i].nColor, AI_tank[i].nDdir);
	}
}

void DrawTank(int x, int y, int color,int dir)
{
	char* tank_figure[3][4] = { { "�� �� ��", "�� �� ��", "�� �� ��", "�� �� ��" },
								{ "�� ���", "�� ���", "�� ��", "�� ��" },
								{ "�� �� ��", "�� �� ��", "�� �� ��", "�� �� ��" } };
	for (int i = 0; i < 3; i++)
	{
		WriteChar(x - 1, y - 1 + i, tank_figure[i][dir], color);
	}
	return;
}

void MoveMyTank(Tank* objTank,int n)
{
	if (!objTank->invisibleFlag)
	{
		ClearTank(objTank->x, objTank->y);
	}
	//Sleep(50);
	switch (n)
	{
	case UP:      objTank->nDdir = 0; objTank->y--; break;
	case DOWN:    objTank->nDdir = 1; objTank->y++; break;
	case LEFT:    objTank->nDdir = 2; objTank->x--; break;
	case RIGHT:   objTank->nDdir = 3; objTank->x++; break;
	default:break;
	}
	if (objTank->nMy == 1)
	{
		Chekmap(&my_Tank);
	}
	else
	{
		Chekmap(&friend_Tank);
	}
	if (!objTank->invisibleFlag)
	{ 
	   DrawTank(objTank->x, objTank->y, objTank->nColor, objTank->nDdir);
	   int nNumX = objTank->x;
	   int nNumY = objTank->y;
	   for (int j = 0; j < 3; j++)
	   {
		   for (int k = 0; k < 3; k++)
		   {
			   g_map[nNumX - 1 + j][nNumY - 1 + k] = my̹��;
		   }
	   }
	}
	ShowCursor(false);
}
void ClearTank(int x, int y)   //���̹��
{
	//system("cls");
	for (int i = 0; i < 3; i++)
	{
		SetPos(x - 1, y - 1 + i);
		printf("     \n");
	}
	
	for (int j = 0; j < 3; j++)
	{
		for (int k = 0; k < 3; k++)
		{
			g_map[x - 1 + j][y - 1 + k] = �յ�;
		}
	}
}

void MoveAiTank(Tank Tanks[])
{
	for (int i = 0; i < 3; i++)
	{
		if (Tanks[i].nAlive == 1)
		{
			if (!Tanks[i].invisibleFlag)
			{
				ClearTank(Tanks[i].x, Tanks[i].y);
			}
			if (rand() % 10 == 0)
			{
				Tanks[i].nDdir = (i + rand()) % 4;
			}
			if (Tanks[i].nStop == 1)
			{
				Tanks[i].nDdir = (i + rand() + 5) % 4;
			}
			switch (Tanks[i].nDdir)
			{
			case UP:      Tanks[i].y--; break;
			case DOWN:    Tanks[i].y++; break;
			case LEFT:    Tanks[i].x--; break;
			case RIGHT:   Tanks[i].x++; break;
			default:break;
			}
			Chekmap(&AI_tank[i]);

			if (!Tanks[i].invisibleFlag)
			{
				DrawTank(Tanks[i].x, Tanks[i].y, Tanks[i].nColor, Tanks[i].nDdir);
				int nNumX = Tanks[i].x;
				int nNumY = Tanks[i].y;
				for (int j = 0; j < 3; j++)
				{
					for (int k = 0; k < 3;k++)
					{ 
						g_map[nNumX - 1 + j][nNumY - 1 + k] = AI̹��;
					}
				}
			}
			else
			{
				Tanks[i].invisibleFlag++;
			}
			ShowCursor(false);
		}
		else
			continue;
	}
}

void InitMyTank()
{
	PlaySoundA(".\\Music\\Relive.wav", NULL, SND_ASYNC | SND_NODEFAULT);
	if (friend_Tank.nAlive == 0&&g_Double==1)
	{
		friend_Tank.x = 25;
		friend_Tank.y = 38;
		friend_Tank.nColor = 9 | 8;
		friend_Tank.nDdir = 0;
		friend_Tank.nRevive --;
		friend_Tank.nMy = 2;
		friend_Tank.nAlive = 1;
		friend_Tank.bulletFlaf = 0;
		DrawTank(friend_Tank.x, friend_Tank.y, friend_Tank.nColor, friend_Tank.nDdir);
	}
	if (my_Tank.nAlive == 0)
	{
		my_Tank.x = 15;
		my_Tank.y = 38;
		my_Tank.nColor = 7 | 8;
		my_Tank.nDdir = 0;
		my_Tank.nRevive --;
		my_Tank.nMy = 1;
		my_Tank.nAlive = 1;
		my_Tank.bulletFlaf = 0;
		DrawTank(my_Tank.x, my_Tank.y, my_Tank.nColor, my_Tank.nDdir);
	}
}

void InitAiTank()                                //����Ai̹���Զ�ˢ�¹���8.9
{
	int pos[3] = { 2, 20, 38 };
	srand((unsigned)time(0));
	int n = rand() % 2;
		for (int i = 0; i < 3; i++)
		{
			if (AI_tank[i].nAlive == 0)
			{
				AI_tank[i].x = pos[n];
				AI_tank[i].y = 2;
				AI_tank[i].nColor = rand() % 6;
				AI_tank[i].nDdir = 1;
				AI_tank[i].nNnum = 9 - g_AiTankNumFlag + 3;
				AI_tank[i].nAlive = 1;
				AI_tank[i].nStop = 0;
				AI_tank[i].bulletFlaf = 0;
				DrawTank(AI_tank[i].x, AI_tank[i].y, AI_tank[i].nColor, AI_tank[i].nDdir);	
			}
	     }
		g_BulletNumFlag--;
}