#pragma once            //ȥ���ظ�����
#include "stdafx.h"

void buildBullet(Tank* tanks, int n);
void checkBullet();
void moveBullet(Tank* tanks);
void moveAiBullet(Tank* tanks, int n);
int FindAiTank(Bullet objNum);
int BulletCheckMap(Bullet* objBullet);
void ClearAI(Bullet objBullet);
void ClearObstacle(Bullet objBullet);
void MyTankRelive(Bullet objBullet);
