#pragma once

void InitGame();
void SetPos(int x, int y);
void WriteChar(int x, int y, char* str, int color);
void ShowCursor(bool isShow);
void GetMap();
void DrawMap();
char GetOper();
void ShowMenu();
int CheckPlaerInput(int m, int n, char* Str[]);
void ClearScre(int x, int y, int n);
void EditMap();
void GameOver(bool home);
void Welcome();